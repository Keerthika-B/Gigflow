import Gig from "../models/gig.js";
import Bid from "../models/bid.js";

export const createBid = async (req, res) => {
  const { gigId, price, message } = req.body;

  // 1️⃣ Check if gig exists
  const gig = await Gig.findById(gigId);
  if (!gig) {
    return res.status(404).json({ message: "Gig not found" });
  }

  // 2️⃣ Prevent bidding on assigned gig
  if (gig.status === "assigned") {
    return res
      .status(400)
      .json({ message: "This gig is already assigned" });
  }

  // 3️⃣ Prevent duplicate bid by same freelancer
  const existingBid = await Bid.findOne({
    gigId,
    freelancerId: req.user.id,
  });

  if (existingBid) {
    return res
      .status(400)
      .json({ message: "You have already placed a bid on this gig" });
  }

  // 4️⃣ Create bid
  const bid = await Bid.create({
    gigId,
    freelancerId: req.user.id,
    price,
    message,
  });

  res.status(201).json(bid);
};


// Client views bids for a gig
export const getBidsByGig = async (req, res) => {
  const bids = await Bid.find({ gigId: req.params.gigId })
    .populate("freelancerId", "name email");

  res.json(bids);
};



export const hireBid = async (req, res) => {
  const bid = await Bid.findById(req.params.bidId);

  if (!bid) {
    return res.status(404).json({ message: "Bid not found" });
  }

  // 1️⃣ Prevent rehiring
  const gig = await Gig.findById(bid.gigId);
  if (gig.status === "assigned") {
    return res.status(400).json({ message: "Gig already assigned" });
  }

  // 2️⃣ Mark selected bid as hired
  bid.status = "hired";
  await bid.save();

  // 3️⃣ Reject all other bids
  await Bid.updateMany(
    { gigId: bid.gigId, _id: { $ne: bid._id } },
    { status: "rejected" }
  );

  // 4️⃣ Update gig status (THIS WAS MISSING)
  gig.status = "assigned";
  gig.assignedTo = bid.freelancerId;
  await gig.save();

  res.json({ message: "Freelancer hired successfully" });
};

