import Gig from "../models/gig.js";

/**
 * CREATE A GIG (CLIENT)
 */
export const createGig = async (req, res) => {
  const { title, description, budget } = req.body;

  const gig = await Gig.create({
    title,
    description,
    budget,
    client: req.user.id,
    status: "open", // ✅ FORCE DEFAULT
  });

  res.status(201).json(gig);
};


/**
 * GET ALL GIGS (FREELANCER)
 */
export const getAllGigs = async (req, res) => {
  const gigs = await Gig.find().populate("client", "name email");
  res.json(gigs);
};

/**
 * GET CLIENT'S OWN GIGS
 */
export const getMyGigs = async (req, res) => {
  const gigs = await Gig.find({ client: req.user._id });
  res.json(gigs);
};
