import express from "express";
import { protect } from "../middleware/authmiddleware.js";
import {
  createBid,
  getBidsByGig,
  hireBid,
} from "../controllers/bidcontroller.js";

const router = express.Router();

router.post("/", protect, createBid);
router.get("/:gigId", protect, getBidsByGig);
router.patch("/:bidId/hire", protect, hireBid);

export default router;
