import express from "express";
import { protect } from "../middleware/authmiddleware.js";
import {
  createGig,
  getAllGigs,
  getMyGigs
} from "../controllers/gigcontroller.js";

const router = express.Router();

router.post("/", protect, createGig);
router.get("/", protect, getAllGigs);
router.get("/my", protect, getMyGigs);

export default router;
