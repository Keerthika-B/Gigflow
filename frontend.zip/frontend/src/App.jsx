import { BrowserRouter, Routes, Route } from "react-router-dom";
import CreateGig from "./pages/CreateGig";
import ViewBids from "./pages/ViewBids";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ClientDashboard from "./pages/ClientDashboard";
import FreelancerDashboard from "./pages/FreelancerDashboard";
import ProtectedRoute from "./components/ProtectedRoute";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* CLIENT ONLY */}
        <Route
          path="/client"
          element={
            <ProtectedRoute role="client">
              <ClientDashboard />
            </ProtectedRoute>
          }
        />

        {/* FREELANCER ONLY */}
        <Route
          path="/freelancer"
          element={
            <ProtectedRoute role="freelancer">
              <FreelancerDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/create-gig"
          element={
            <ProtectedRoute role="client">
               <CreateGig />
            </ProtectedRoute>
          }
       />
       <Route
          path="/gigs/:id/bids"
          element={
             <ProtectedRoute role="client">
                <ViewBids />
             </ProtectedRoute>
          }
       />

      </Routes>
    </BrowserRouter>
  );
}

export default App;
