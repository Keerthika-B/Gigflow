export default function BidCard({ bid, onHire }) {
  return (
    <div style={styles.card}>
      <p><strong>Freelancer:</strong> {bid.freelancer.name}</p>
      <p><strong>Message:</strong> {bid.message}</p>
      <p><strong>Price:</strong> ₹{bid.price}</p>

      <p>
        <strong>Status:</strong>{" "}
        <span style={statusStyle(bid.status)}>
          {bid.status}
        </span>
      </p>

      {bid.status === "pending" && (
        <button onClick={() => onHire(bid._id)}>
          Hire
        </button>
      )}
    </div>
  );
}

const statusStyle = (status) => {
  if (status === "hired") return { color: "green" };
  if (status === "rejected") return { color: "red" };
  return { color: "orange" };
};

const styles = {
  card: {
    border: "1px solid #aaa",
    padding: "12px",
    marginBottom: "10px",
    borderRadius: "6px",
    backgroundColor: "#fafafa",
  },
};
