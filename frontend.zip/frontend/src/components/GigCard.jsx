export default function GigCard({ gig, onViewBids, onBid }) {
  return (
    <div style={styles.card}>
      <h3>{gig.title}</h3>
      <p>{gig.description}</p>

      <p>
        <strong>Budget:</strong> ₹{gig.budget}
      </p>

      <p>
        <strong>Status:</strong>{" "}
        <span style={{ color: gig.status === "open" ? "green" : "orange" }}>
          {gig.status}
        </span>
      </p>

      {/* Client action */}
      {onViewBids && (
        <button onClick={() => onViewBids(gig._id)}>
          View Bids
        </button>
      )}

      {/* Freelancer action */}
      {onBid && (
        <button onClick={() => onBid(gig._id)}>
          Place Bid
        </button>
      )}
    </div>
  );
}

const styles = {
  card: {
    border: "1px solid #ccc",
    padding: "15px",
    marginBottom: "10px",
    borderRadius: "6px",
  },
};
