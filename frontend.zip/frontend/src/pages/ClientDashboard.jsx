import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api/api";
import GigCard from "../components/GigCard";

export default function ClientDashboard() {
  const [gigs, setGigs] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    API.get("/gigs").then(res => setGigs(res.data));
  }, []);

  const logout = () => {
    localStorage.clear();
    window.location.href = "/login";
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <div style={styles.header}>
          <h2>Client Dashboard</h2>

          <div style={styles.actions}>
            <button
              style={styles.primaryButton}
              onClick={() => navigate("/create-gig")}
            >
              + Create New Gig
            </button>

            <button
              style={styles.logoutButton}
              onClick={logout}
            >
              Logout
            </button>
          </div>
        </div>

        <hr style={styles.divider} />

        {gigs.length === 0 && (
          <p style={styles.emptyText}>No gigs created yet</p>
        )}

        {gigs.map(gig => (
          <GigCard
            key={gig._id}
            gig={gig}
            onViewBids={(id) => navigate(`/gigs/${id}/bids`)}
          />
        ))}
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#f4f6f8",
    padding: "30px",
  },
  container: {
    maxWidth: "900px",
    margin: "0 auto",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  actions: {
    display: "flex",
    gap: "10px",
  },
  primaryButton: {
    padding: "10px 16px",
    background: "#2563eb",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
  },
  logoutButton: {
    padding: "10px 16px",
    background: "#dc2626",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
  },
  divider: {
    margin: "20px 0",
  },
  emptyText: {
    textAlign: "center",
    color: "#666",
  },
};
