import { useEffect, useState } from "react";
import API from "../api/api";
import GigCard from "../components/GigCard";

export default function FreelancerDashboard() {
  const [gigs, setGigs] = useState([]);
  const [price, setPrice] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    const fetchGigs = async () => {
      const res = await API.get("/gigs");
      const openGigs = res.data.filter(g => g.status === "open");
      setGigs(openGigs);
    };
    fetchGigs();
  }, []);

  const logout = () => {
    localStorage.clear();
    window.location.href = "/login";
  };

  const placeBid = async (gigId) => {
    if (!price || !message) {
      alert("Please enter price and message");
      return;
    }

    try {
      await API.post("/bids", { gigId, price, message });
      alert("Bid placed successfully");
      setPrice("");
      setMessage("");
    } catch (err) {
      alert("Failed to place bid");
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <div style={styles.header}>
          <h2>Freelancer Dashboard</h2>

          <button
            style={styles.logoutButton}
            onClick={logout}
          >
            Logout
          </button>
        </div>

        <div style={styles.bidBox}>
          <input
            style={styles.input}
            type="number"
            placeholder="Your price (₹)"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
          />

          <input
            style={styles.input}
            placeholder="Message to client"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
        </div>

        <hr style={styles.divider} />

        {gigs.length === 0 && (
          <p style={styles.emptyText}>No open gigs available</p>
        )}

        {gigs.map(gig => (
          <GigCard
            key={gig._id}
            gig={gig}
            onBid={placeBid}
          />
        ))}
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#f4f6f8",
    padding: "30px",
  },
  container: {
    maxWidth: "900px",
    margin: "0 auto",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  logoutButton: {
    padding: "10px 16px",
    background: "#dc2626",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
  },
  bidBox: {
    display: "flex",
    gap: "10px",
    marginTop: "15px",
  },
  input: {
    flex: 1,
    padding: "10px",
    borderRadius: "4px",
    border: "1px solid #ccc",
  },
  divider: {
    margin: "20px 0",
  },
  emptyText: {
    textAlign: "center",
    color: "#666",
  },
};
