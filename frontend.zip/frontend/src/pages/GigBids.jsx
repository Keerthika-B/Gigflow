import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import API from "../api/api";
import BidCard from "../components/BidCard";

export default function GigBids() {
  const { gigId } = useParams();
  const [bids, setBids] = useState([]);

  const loadBids = async () => {
    const res = await API.get(`/bids/${gigId}`);
    setBids(res.data);
  };

  useEffect(() => {
    loadBids();
  }, []);

  const hireBid = async (bidId) => {
    await API.patch(`/bids/${bidId}/hire`);
    alert("Freelancer hired successfully");
    loadBids();
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <h2 style={styles.heading}>Gig Bids</h2>

        {bids.length === 0 && (
          <p style={styles.empty}>No bids yet</p>
        )}

        {bids.map(bid => (
          <BidCard
            key={bid._id}
            bid={bid}
            onHire={(id) => hireBid(id)}
          />
        ))}
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#f4f6f8",
    padding: "30px",
  },
  container: {
    maxWidth: "900px",
    margin: "0 auto",
  },
  heading: {
    marginBottom: "20px",
  },
  empty: {
    textAlign: "center",
    color: "#666",
  },
};
