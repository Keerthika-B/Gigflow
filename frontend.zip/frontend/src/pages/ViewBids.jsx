import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import API from "../api/api";

export default function ViewBids() {
  const { id } = useParams();
  const [bids, setBids] = useState([]);

  useEffect(() => {
    const fetchBids = async () => {
      try {
        const res = await API.get(`/bids/${id}`);
        setBids(res.data);
      } catch (err) {
        alert("Failed to load bids");
      }
    };

    fetchBids();
  }, [id]);

  const hireFreelancer = async (bidId) => {
    try {
      await API.patch(`/bids/${bidId}/hire`);
      alert("Freelancer hired successfully");
      window.location.href = "/client";
    } catch (err) {
      alert("Failed to hire freelancer");
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <h2 style={styles.heading}>Bids</h2>

        {bids.length === 0 && (
          <p style={styles.empty}>No bids yet</p>
        )}

        {bids.map(bid => (
          <div key={bid._id} style={styles.card}>
            <p><strong>Message:</strong> {bid.message}</p>
            <p><strong>Price:</strong> ₹{bid.price}</p>
            <p><strong>Status:</strong> {bid.status}</p>

            {bid.status === "pending" && (
              <button
                style={styles.button}
                onClick={() => hireFreelancer(bid._id)}
              >
                Hire
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#f4f6f8",
    padding: "30px",
  },
  container: {
    maxWidth: "800px",
    margin: "0 auto",
  },
  heading: {
    marginBottom: "20px",
  },
  empty: {
    textAlign: "center",
    color: "#666",
  },
  card: {
    border: "1px solid #ccc",
    borderRadius: "6px",
    padding: "15px",
    marginBottom: "10px",
    background: "#fff",
  },
  button: {
    marginTop: "10px",
    padding: "8px 14px",
    background: "#16a34a",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
};
